fglrx-8.97.100.7
================

fglrx-8.97.100.7 ( amd-driver-installer-catalyst-13.1-legacy-linux-x86.x86_64.run ) for linux kernel 3.4.XX ... 3.10.XX

AMD legacy cards <= Radeon HD 4000 series and HD series AGP