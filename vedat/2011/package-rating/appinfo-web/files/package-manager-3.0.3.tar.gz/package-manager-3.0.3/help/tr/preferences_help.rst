Tercihler
---------

Bu pencerede güncelleme sıklığı, önbellek ayarları, vekil sunucu ve depo
ayarlarını tanımlayabilirsiniz.


Genel ayarlar
-------------

Paket yöneticisinin sistem çekmecesi simgesinin gösterilmesi, paket güncelleme
kontrolü aralığı gibi ayarlarınızı yapabilirsiniz.


Önbellek
--------

İndirilen paketler için azami önbellek miktarını tanımlayabilirsiniz.
"Önbelleği Temizle" tuşu, diskinizin önbellek adresinde bulunan tüm ikili
paketleri silecektir. Bu işlem sistem kararlığını etkilemeyecek ve sisteminizde
kurulu paketleri silmeyecektir.

Depolar
-------

Yeni depo ekleyebilir, mevcut depolarınızı düzenleyebilir veya
kaldırabilirsiniz.

Vekil Sunucu Ayarları
---------------------

Bu alanda vekil sunucunuzu tanımlayabilirsiniz. Vekil sunucu ayarlarını elle
girebilir veya bulunduğunuz masaüstü ortamında tanımlı olan bir ayarı
kullanabilirsiniz.


