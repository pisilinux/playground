pref("general.useragent.compatMode.firefox", true);
// Forbid application updates
lockPref("app.update.enabled", false);
