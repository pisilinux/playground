//@line 2 "/build/buildd-iceweasel_6.0~b5-1-i386-7Sebyl/iceweasel-6.0~b5/browser/app/profile/channel-prefs.js"
pref("app.update.channel", "default");
